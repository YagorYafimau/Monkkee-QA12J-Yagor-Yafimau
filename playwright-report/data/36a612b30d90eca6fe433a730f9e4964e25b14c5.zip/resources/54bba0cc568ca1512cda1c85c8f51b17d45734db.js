/**
 * Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.editorConfig = function( config ) {
	config.extraPlugins = 'autosave,bidi,close,image2,link,moreorless,pastefromword,savetoggle,simplemaximize,timestamp';
	config.toolbarGroups = [
		{ name: 'editing', groups: [ 'basicstyles', 'list', 'indent', 'align', 'blocks', 'bidi', 'colors' ] },
		{ name: 'insert', groups: [ 'links', 'image', 'horizontalrule', 'specialchar', 'smiley', 'timestamp' ] },
		{ name: 'styles', groups: [ 'format', 'font', 'fontsize' ] },
		{ name: 'cleanup' },
		{ name: 'state', groups: [ 'undo', 'savetoggle' ] },
		{ name: 'usability' },
		{ name: 'toolbarcontrol' }
	];

	config.removeButtons = 'Cut,Copy,Paste,Anchor,Subscript,Superscript';

	config.removeDialogTabs = 'image:advanced;image:Link;link:target;link:upload';

	config.floatSpacePreferLeft = true;
	config.floatSpacePreferRight = false;
	config.linkShowAdvancedTab = false;
	config.linkShowTargetTab = false;

	config.disableNativeSpellChecker = false;
	config.smiley_path = location.protocol + '//' + location.host + '/javascripts/ckeditor-current/plugins/smiley/images/';

	config.autosaveCheckInterval = 4500;
	config.saveAfterInactivityTimeout = 3500;

	config.title = false;
};

